// Get the canvas and context
const canvas = document.getElementById('coloringCanvas');
const ctx = canvas.getContext('2d');
const colorPicker = document.getElementById('colorPicker');
const eraserButton = document.getElementById('eraserButton'); // Get eraser button reference

// Variables for drawing
let isDrawing = false;
let color = colorPicker.value;
let isErasing = false;

// Update color when user selects a new one from the color picker
colorPicker.addEventListener('input', () => {
  color = colorPicker.value;
});

// Function to set color from the palette
function setColor(newColor) {
  color = newColor;
  colorPicker.value = newColor; // Sync with the color picker
}

// Function to activate eraser mode
function useEraser() {
  isErasing = !isErasing; // Toggle eraser mode
  colorPicker.disabled = isErasing; // Disable color picker when erasing
  eraserButton.disabled = !isErasing; // Disable the eraser button itself
}

// Start drawing
canvas.addEventListener('mousedown', (event) => {
  isDrawing = true;
  ctx.beginPath();
  ctx.moveTo(event.offsetX, event.offsetY); // Set starting point
});

// Draw on the canvas
canvas.addEventListener('mousemove', (event) => {
  if (!isDrawing) return;

  if (isErasing) {
    // Clear a small rectangle
    ctx.clearRect(event.offsetX - 5, event.offsetY - 5, 10, 10);
  } else {
    ctx.lineTo(event.offsetX, event.offsetY);
    ctx.strokeStyle = color;
    ctx.lineWidth = 5;
    ctx.stroke();
  }
});

// Stop drawing
canvas.addEventListener('mouseup', () => {
  isDrawing = false;
  isErasing = false;
  colorPicker.disabled = false;
});

// Clear the canvas
function clearCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// Fill the entire canvas with the selected color
document.getElementById("fillButton").addEventListener("click", () => {
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, canvas.width, canvas.height); // Fill the entire canvas
});